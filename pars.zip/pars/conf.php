﻿<?php

// Credentials for MYSQL database
	$host="localhost";
	$user="dialeruser";
	$pass="dialerpass";
	$db="dialerdb";


?>
