<?php
/**
* @file
*
* All Callblaster code is released under the GNU General Public License.
* See COPYRIGHT.txt and LICENSE.txt.
*
*....................
* www.nethram.com
*/

?>
<html>

<center>

<strong> A P I , U R L </strong>

<h3> http://[issabelip]/pars/api.php?action=democall&phone=[phone_number]&file=[audio_name.wav]&action=call </h3>

<h2> For example :</h2>

<h3> http://192.168.1.150/pars/api.php?action=democall&phone=91999&file=welcome.wav&action=call </h3>

				<strong><a href="index.php"> Main Page </a></strong>


</html>
