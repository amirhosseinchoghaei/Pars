  <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <!-- <b>Version</b> 2.3.0 -->
        </div>
        <strong>Copyright &copy; 2016-2019 <a href="http://techextension.com" target="new">TechExtension</a>.</strong> All rights reserved.<b> Version 1.1</b>
      </footer>