  <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <!-- <b>Version</b> 2.3.0 -->
        </div>
        <strong>Powered By Amir Hossein</a>.</strong> All rights reserved.<b></b>
      </footer>